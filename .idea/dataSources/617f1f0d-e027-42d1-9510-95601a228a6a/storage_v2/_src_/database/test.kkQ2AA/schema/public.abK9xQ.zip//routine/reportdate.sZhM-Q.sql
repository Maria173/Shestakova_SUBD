create function reportdate(after timestamp without time zone, before timestamp without time zone)
    returns TABLE(group_class character varying, student character varying, subject character varying, grade integer)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
G.group_name AS Group, 
St.student_surname AS Student,
Su.subject_name AS Subject,
H.grade
FROM grade_sheet Gs
JOIN group_class G ON Gs.group_id = G.id
JOIN student St ON Gs.group_id = St.group_id
JOIN subject Su ON Su.id = Gs.subject_id
JOIN subgrade_sheet H ON H.grade_sheet_id = Gs.id
WHERE St.birthdate>AFTER AND St.birthdate<BEFORE;
END;
$$;

alter function reportdate(timestamp, timestamp) owner to testuser;

